                <form action="<?php echo home_url('/'); ?>">
                    <input type="text" value="<?php echo get_search_query() ?>" name="s" id="s" placeholder="Поиск" required>
                    <button>Найти</button>
                </form>
<?php
/*
Template Name: Оплата
*/
?>
<?php 
//not used
 ?>
<?php get_header(); ?>
<div class="questions">
            <div class="wrapper">
                <div class="inside-questions">
                    <div class="pre-questions">
                        <h4 class="help-name-question">Обратная связь</h4>
                    </div>
                </div>
                <div class="help-main">
                    <div class="help-side">
                        <?php get_template_part('templates/nav', 'side'); ?>
                    </div>
                    <div class="help-answer">
                        <p class="question-name">Оплата</p>
                        <div class="pay-way-block">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>   
<?php get_footer(); ?>
